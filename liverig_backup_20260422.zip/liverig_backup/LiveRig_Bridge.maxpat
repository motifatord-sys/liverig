{
	"patcher" : {
		"fileversion" : 1,
		"appversion" : { "major" : 8, "minor" : 6, "revision" : 0, "architecture" : "x64", "modernui" : 1 },
		"classnamespace" : "dsp.midi",
		"rect" : [ 50.0, 50.0, 1100.0, 720.0 ],
		"boxes" : [
			{ "box" : { "id" : "obj-1",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "outlettype" : [ "bang" ], "patching_rect" : [ 30.0, 30.0, 120.0, 22.0 ], "text" : "live.thisdevice" } },
			{ "box" : { "id" : "obj-2",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "outlettype" : [ "bang" ], "patching_rect" : [ 170.0, 30.0, 80.0, 22.0 ], "text" : "loadbang" } },
			{ "box" : { "id" : "obj-3",  "maxclass" : "newobj", "numinlets" : 2, "numoutlets" : 1, "outlettype" : [ "bang" ], "patching_rect" : [ 30.0, 70.0, 80.0, 22.0 ], "text" : "metro 100" } },
			{ "box" : { "id" : "obj-comment", "maxclass" : "comment", "numinlets" : 1, "numoutlets" : 0, "patching_rect" : [ 30.0, 105.0, 1040.0, 20.0 ], "text" : "LiveRig Bridge v5 — sends JSON via UDP to Python bridge on localhost:9000. No MIDI feedback traffic." } },

			{ "box" : { "id" : "obj-4",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 6, "outlettype" : [ "int", "float", "float", "int", "int", "int" ], "patching_rect" : [ 30.0, 140.0, 80.0, 22.0 ], "text" : "transport" } },
			{ "box" : { "id" : "obj-c1", "maxclass" : "comment", "numinlets" : 1, "numoutlets" : 0, "patching_rect" : [ 120.0, 140.0, 500.0, 20.0 ], "text" : "out1=playstate(0/1/2)  out2=position(beats)  out3=tempo  out4=timesig_num  out5=timesig_denom  out6=loop" } },

			{ "box" : { "id" : "obj-5",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 3, "outlettype" : [ "bang", "bang", "int" ], "patching_rect" : [ 30.0, 175.0, 70.0, 22.0 ], "text" : "sel 0 1 2" } },
			{ "box" : { "id" : "obj-6",  "maxclass" : "message", "numinlets" : 2, "numoutlets" : 1, "patching_rect" : [ 30.0, 205.0, 70.0, 22.0 ], "text" : "stopped" } },
			{ "box" : { "id" : "obj-7",  "maxclass" : "message", "numinlets" : 2, "numoutlets" : 1, "patching_rect" : [ 110.0, 205.0, 60.0, 22.0 ], "text" : "playing" } },
			{ "box" : { "id" : "obj-8",  "maxclass" : "message", "numinlets" : 2, "numoutlets" : 1, "patching_rect" : [ 180.0, 205.0, 80.0, 22.0 ], "text" : "recording" } },
			{ "box" : { "id" : "obj-9",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 30.0, 235.0, 80.0, 22.0 ], "text" : "tosymbol" } },
			{ "box" : { "id" : "obj-ts", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 30.0, 265.0, 120.0, 22.0 ], "text" : "s liverig_transport" } },

			{ "box" : { "id" : "obj-10", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 280.0, 175.0, 80.0, 22.0 ], "text" : "/ 4" } },
			{ "box" : { "id" : "obj-11", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 280.0, 205.0, 40.0, 22.0 ], "text" : "int" } },
			{ "box" : { "id" : "obj-sb", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 280.0, 235.0, 110.0, 22.0 ], "text" : "s liverig_bar" } },

			{ "box" : { "id" : "obj-12", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 430.0, 175.0, 80.0, 22.0 ], "text" : "ftoi" } },
			{ "box" : { "id" : "obj-st", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 430.0, 205.0, 110.0, 22.0 ], "text" : "s liverig_tempo" } },

			{ "box" : { "id" : "obj-13", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 580.0, 175.0, 40.0, 22.0 ], "text" : "int" } },
			{ "box" : { "id" : "obj-sn", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 580.0, 205.0, 120.0, 22.0 ], "text" : "s liverig_timesig" } },

			{ "box" : { "id" : "obj-lapi", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 2, "patching_rect" : [ 30.0, 310.0, 260.0, 22.0 ], "text" : "live.object @path live_set" } },
			{ "box" : { "id" : "obj-gn",  "maxclass" : "message", "numinlets" : 2, "numoutlets" : 1, "patching_rect" : [ 30.0, 340.0, 80.0, 22.0 ], "text" : "get name" } },
			{ "box" : { "id" : "obj-rn",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 2, "patching_rect" : [ 30.0, 370.0, 100.0, 22.0 ], "text" : "route name" } },
			{ "box" : { "id" : "obj-ssong","maxclass" : "newobj","numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 30.0, 400.0, 120.0, 22.0 ], "text" : "s liverig_song" } },

			{ "box" : { "id" : "obj-lapi2","maxclass" : "newobj","numinlets" : 1, "numoutlets" : 2, "patching_rect" : [ 400.0, 310.0, 260.0, 22.0 ], "text" : "live.object @path live_set" } },
			{ "box" : { "id" : "obj-gcue", "maxclass" : "message","numinlets" : 2, "numoutlets" : 1, "patching_rect" : [ 400.0, 340.0, 120.0, 22.0 ], "text" : "get cue_points" } },
			{ "box" : { "id" : "obj-rcue", "maxclass" : "newobj","numinlets" : 1, "numoutlets" : 2, "patching_rect" : [ 400.0, 370.0, 130.0, 22.0 ], "text" : "route cue_points" } },
			{ "box" : { "id" : "obj-scue", "maxclass" : "newobj","numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 400.0, 400.0, 130.0, 22.0 ], "text" : "s liverig_locators" } },

			{ "box" : { "id" : "obj-r1",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "patching_rect" : [ 30.0, 460.0, 140.0, 22.0 ], "text" : "r liverig_transport" } },
			{ "box" : { "id" : "obj-r2",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "patching_rect" : [ 185.0, 460.0, 120.0, 22.0 ], "text" : "r liverig_bar" } },
			{ "box" : { "id" : "obj-r3",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "patching_rect" : [ 315.0, 460.0, 120.0, 22.0 ], "text" : "r liverig_tempo" } },
			{ "box" : { "id" : "obj-r4",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "patching_rect" : [ 445.0, 460.0, 130.0, 22.0 ], "text" : "r liverig_timesig" } },
			{ "box" : { "id" : "obj-r5",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "patching_rect" : [ 585.0, 460.0, 120.0, 22.0 ], "text" : "r liverig_song" } },
			{ "box" : { "id" : "obj-r6",  "maxclass" : "newobj", "numinlets" : 0, "numoutlets" : 1, "patching_rect" : [ 715.0, 460.0, 140.0, 22.0 ], "text" : "r liverig_locators" } },

			{ "box" : { "id" : "obj-js",  "maxclass" : "newobj", "numinlets" : 7, "numoutlets" : 1, "patching_rect" : [ 30.0, 500.0, 860.0, 22.0 ], "text" : "dict.serialize @format json" } },

			{ "box" : { "id" : "obj-udp", "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 0, "patching_rect" : [ 30.0, 540.0, 200.0, 22.0 ], "text" : "udpsend 127.0.0.1 9000" } },

			{ "box" : { "id" : "obj-note2","maxclass" : "comment","numinlets" : 1, "numoutlets" : 0, "patching_rect" : [ 30.0, 580.0, 800.0, 40.0 ], "text" : "SETUP: Drop on any MIDI track. Python bridge must be running. Data flows: M4L → UDP:9000 → Bridge → WebSocket → iPad. No MIDI feedback traffic." } },

			{ "box" : { "id" : "obj-mi",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 2, "patching_rect" : [ 850.0, 460.0, 60.0, 22.0 ], "text" : "midiin" } },
			{ "box" : { "id" : "obj-mf",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 850.0, 490.0, 80.0, 22.0 ], "text" : "midiparse" } },
			{ "box" : { "id" : "obj-c2",  "maxclass" : "comment", "numinlets" : 1, "numoutlets" : 0, "patching_rect" : [ 850.0, 440.0, 220.0, 20.0 ], "text" : "SysEx from bridge → locator jump" } },
			{ "box" : { "id" : "obj-sx",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 2, "patching_rect" : [ 850.0, 520.0, 60.0, 22.0 ], "text" : "sel 240" } },
			{ "box" : { "id" : "obj-lj",  "maxclass" : "newobj", "numinlets" : 1, "numoutlets" : 1, "patching_rect" : [ 850.0, 550.0, 200.0, 22.0 ], "text" : "print locator_jump" } }
		],
		"lines" : [
			{ "patchline" : { "source" : [ "obj-1",  0 ], "destination" : [ "obj-3",  0 ] } },
			{ "patchline" : { "source" : [ "obj-2",  0 ], "destination" : [ "obj-3",  0 ] } },
			{ "patchline" : { "source" : [ "obj-3",  0 ], "destination" : [ "obj-4",  0 ] } },
			{ "patchline" : { "source" : [ "obj-3",  0 ], "destination" : [ "obj-gn",  0 ] } },
			{ "patchline" : { "source" : [ "obj-3",  0 ], "destination" : [ "obj-gcue", 0 ] } },

			{ "patchline" : { "source" : [ "obj-4",  0 ], "destination" : [ "obj-5",  0 ] } },
			{ "patchline" : { "source" : [ "obj-4",  1 ], "destination" : [ "obj-10", 0 ] } },
			{ "patchline" : { "source" : [ "obj-4",  2 ], "destination" : [ "obj-12", 0 ] } },
			{ "patchline" : { "source" : [ "obj-4",  3 ], "destination" : [ "obj-13", 0 ] } },

			{ "patchline" : { "source" : [ "obj-5",  0 ], "destination" : [ "obj-6",  0 ] } },
			{ "patchline" : { "source" : [ "obj-5",  1 ], "destination" : [ "obj-7",  0 ] } },
			{ "patchline" : { "source" : [ "obj-5",  2 ], "destination" : [ "obj-8",  0 ] } },
			{ "patchline" : { "source" : [ "obj-6",  0 ], "destination" : [ "obj-9",  0 ] } },
			{ "patchline" : { "source" : [ "obj-7",  0 ], "destination" : [ "obj-9",  0 ] } },
			{ "patchline" : { "source" : [ "obj-8",  0 ], "destination" : [ "obj-9",  0 ] } },
			{ "patchline" : { "source" : [ "obj-9",  0 ], "destination" : [ "obj-ts", 0 ] } },

			{ "patchline" : { "source" : [ "obj-10", 0 ], "destination" : [ "obj-11", 0 ] } },
			{ "patchline" : { "source" : [ "obj-11", 0 ], "destination" : [ "obj-sb", 0 ] } },

			{ "patchline" : { "source" : [ "obj-12", 0 ], "destination" : [ "obj-st", 0 ] } },
			{ "patchline" : { "source" : [ "obj-13", 0 ], "destination" : [ "obj-sn", 0 ] } },

			{ "patchline" : { "source" : [ "obj-gn",  0 ], "destination" : [ "obj-lapi",  0 ] } },
			{ "patchline" : { "source" : [ "obj-lapi", 0 ], "destination" : [ "obj-rn",   0 ] } },
			{ "patchline" : { "source" : [ "obj-rn",  0 ], "destination" : [ "obj-ssong", 0 ] } },

			{ "patchline" : { "source" : [ "obj-gcue", 0 ], "destination" : [ "obj-lapi2", 0 ] } },
			{ "patchline" : { "source" : [ "obj-lapi2",0 ], "destination" : [ "obj-rcue",  0 ] } },
			{ "patchline" : { "source" : [ "obj-rcue", 0 ], "destination" : [ "obj-scue",  0 ] } },

			{ "patchline" : { "source" : [ "obj-r1",  0 ], "destination" : [ "obj-js",  0 ] } },
			{ "patchline" : { "source" : [ "obj-r2",  0 ], "destination" : [ "obj-js",  1 ] } },
			{ "patchline" : { "source" : [ "obj-r3",  0 ], "destination" : [ "obj-js",  2 ] } },
			{ "patchline" : { "source" : [ "obj-r4",  0 ], "destination" : [ "obj-js",  3 ] } },
			{ "patchline" : { "source" : [ "obj-r5",  0 ], "destination" : [ "obj-js",  4 ] } },
			{ "patchline" : { "source" : [ "obj-r6",  0 ], "destination" : [ "obj-js",  5 ] } },
			{ "patchline" : { "source" : [ "obj-js",  0 ], "destination" : [ "obj-udp", 0 ] } },

			{ "patchline" : { "source" : [ "obj-mi",  0 ], "destination" : [ "obj-mf",  0 ] } },
			{ "patchline" : { "source" : [ "obj-mf",  0 ], "destination" : [ "obj-sx",  0 ] } },
			{ "patchline" : { "source" : [ "obj-sx",  0 ], "destination" : [ "obj-lj",  0 ] } }
		]
	}
}
