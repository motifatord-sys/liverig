LIVERIG BACKUP PACKAGE
======================
Date: April 22, 2026
Repo: https://github.com/motifatord-sys/liverig

FILES IN THIS PACKAGE:
  live_rig_3_controller.html  — iPad controller UI (all 10 pages)
  liverig_bridge_wired.py     — Python WebSocket + UDP bridge (v3)
  LiveRig_Bridge.maxpat       — Max for Live device (v5, rename to .amxd)
  LiveRig_Wired_Start.sh      — macOS launcher script
  LIVERIG_PROJECT_BRIEF.md    — Full project documentation
  README.txt                  — This file

QUICK SETUP:
  1. Copy all files to ~/Desktop/liverig/
  2. Rename LiveRig_Bridge.maxpat → LiveRig_Bridge.amxd
  3. Run: bash LiveRig_Wired_Start.sh
  4. In Ableton: drop LiveRig_Bridge.amxd on a MIDI track

See LIVERIG_PROJECT_BRIEF.md for full documentation.
