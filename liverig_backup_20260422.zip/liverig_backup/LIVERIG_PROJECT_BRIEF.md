# LiveRig — Complete Project Brief & Recovery Document
**Generated:** April 22, 2026  
**Status:** Active Development  
**Repo:** https://github.com/motifatord-sys/liverig  
**Mac User:** dparks @ The-Beast-2147

---

## 1. PROJECT OVERVIEW

LiveRig is a custom iPad MIDI controller for Ableton Live Suite 12.3.7, built specifically for live performance. The system replaces hardware MIDI controllers with a full-screen iPad Safari web app connected to a Mac via USB cable (no WiFi dependency).

**Core philosophy:**
- USB only — no WiFi, no Bluetooth, no latency surprises on stage
- Self-contained — one click launches everything
- Bidirectional — iPad controls Ableton AND Ableton feeds back to iPad in real time

---

## 2. SYSTEM ARCHITECTURE

```
iPad Safari (live_rig_3_controller.html)
        ↕ WebSocket (port 8765) over USB
Mac Python Bridge (liverig_bridge_wired.py)
        ↕ Virtual MIDI port "LiveRig Bridge"
Ableton Live Suite 12.3.7
        ↕ Max for Live device (LiveRig_Bridge.amxd)
        ↕ UDP JSON (localhost port 9000) → Python Bridge
```

### Data flow — OUTBOUND (iPad → Ableton):
- iPad sends JSON arrays of raw MIDI bytes over WebSocket
- Python bridge receives and forwards to virtual MIDI port
- Ableton receives on "LiveRig Bridge" input

### Data flow — INBOUND (Ableton → iPad):  
- M4L device polls Live state every 100ms
- Sends JSON via UDP to localhost:9000
- Python bridge receives UDP, forwards as JSON over WebSocket
- iPad receives and updates UI (BPM, transport, clips, track names, locators)

### Why UDP not MIDI for feedback:
- MIDI is 31,250 baud — too slow for dense live state
- All MIDI channels already used for control
- UDP over localhost is essentially unlimited bandwidth
- Cleaner — named JSON keys vs raw CC values

---

## 3. FILE INVENTORY

### On Mac (~/Desktop/liverig/):
| File | Purpose |
|------|---------|
| `live_rig_3_controller.html` | iPad controller UI — all pages |
| `liverig_bridge_wired.py` | Python WebSocket + UDP bridge |
| `LiveRig_Wired_Start.sh` | macOS launcher script |
| `LiveRig_Bridge.amxd` | Max for Live device (feedback) |
| `LiveRig_1.0.dmg` | Installer DMG |

### macOS App:
- `LiveRig.app` in `/Applications`
- Built with Script Editor AppleScript
- Launches `LiveRig_Wired_Start.sh`
- Custom brushed-steel "L" icon
- Build folder: `~/Desktop/LiveRig_build/`

### GitHub Repo:
- URL: https://github.com/motifatord-sys/liverig
- Branch: main
- All files pushed and up to date

---

## 4. DAILY WORKFLOW

1. Plug iPad into Mac via USB-C
2. Enable **Personal Hotspot** on iPad (required for USB network interface)
3. Click **LiveRig** in Dock
4. Dialog shows URL — open on iPad in Safari
5. Green dot = connected, MIDI flowing

### First-time setup:
- Ableton Preferences → MIDI:
  - Input "LiveRig Bridge": Track ON, Remote ON
  - Output "LiveRig Bridge": Track ON, Remote ON
- Drop `LiveRig_Bridge.amxd` on any MIDI track in Ableton

---

## 5. IPAD CONTROLLER — PAGES

| Tab | Page | Description |
|-----|------|-------------|
| Master | 0 | 16 toggle buttons (K1-K4 × 4) + 8 volume faders |
| Transport | 8 | Play/Stop/Rec/Overdub + BPM display + tap tempo + beat counter |
| Clips | 9 | 8×8 clip launcher grid + scene/track stop |
| Looper | 1 | 4 loop tracks REC/PLAY/STOP + tap tempo + BPM fader |
| Pads | 2 | 16 one-shot pads (CH10) + 4 FX toggles |
| Patches | 3 | 8 song presets (Program Change) |
| Kbd 1-4 | 4-7 | 16 toggle buttons + 8 CC faders per keyboard |

**Setlist page** — PLANNED (see Section 8)

---

## 6. MIDI MAP (CONFLICT-FREE)

### Outbound (iPad → Ableton):
| Feature | Channel | CC/Notes |
|---------|---------|---------|
| Master toggle buttons | CH1-4 | CC20-35 (sequential) |
| Volume faders | CH1-4 | CC7 |
| Loop Rec/Play | CH1-4 | CC80-83 |
| Loop Stop | CH1-4 | CC84-87 |
| Tap tempo (looper) | CH1 | CC89 |
| BPM nudge | CH1 | CC90-91 |
| FX toggles | CH1 | CC70-73 |
| Pads 1-16 | CH10 | Notes 36-51 |
| Program Change | CH1-4 | PC0-7 |
| Transport Play | CH1 | CC116 |
| Transport Stop | CH1 | CC117 |
| Transport Record | CH1 | CC118 |
| Transport Overdub | CH1 | CC119 |
| Metronome | CH1 | CC112 |
| Loop toggle | CH1 | CC113 |
| Punch In | CH1 | CC114 |
| Undo | CH1 | CC115 |
| Redo | CH1 | CC111 |
| Tempo Bend Down | CH1 | CC108 |
| Tempo Bend Up | CH1 | CC107 |
| Clip Launch 8×8 | CH1 | Notes 48-111 |
| Track Stop 1-8 | CH1 | CC52-59 |
| Scene Launch 1-8 | CH1 | CC60-67 |
| Stop All Clips | CH1 | CC68 |
| Locator Jump | — | SysEx F0 7D 30 idx F7 |
| Locator Next | — | SysEx F0 7D 31 00 F7 |
| Locator Prev | — | SysEx F0 7D 32 00 F7 |

### Inbound (Ableton → iPad) — via UDP JSON, NOT MIDI:
All feedback travels as JSON over UDP→WebSocket. No MIDI channels used for feedback.

---

## 7. M4L DEVICE — LiveRig_Bridge.amxd

### What it does:
Polls Ableton Live state every 100ms and sends JSON via UDP to localhost:9000.

### JSON payload sent:
```json
{
  "bpm": 128.5,
  "transport": "playing",
  "bar": 14,
  "beat": 3,
  "timesig": [4, 4],
  "tracks": ["Keys", "Bass", "Pad", "Lead", "Tr5", "Tr6", "Tr7", "Tr8"],
  "clips": [[0,1,2,0,0,0,0,0], ...],
  "song": "Song Name",
  "song_len_bars": 64,
  "locators": [
    {"name": "Intro", "bar": 1},
    {"name": "Verse 1", "bar": 5},
    {"name": "Chorus", "bar": 13}
  ],
  "current_locator": "Verse 1"
}
```

### Objects used:
- `transport` — playstate, position, BPM, timesig
- `live.object @path live_set` — song name, cue points
- `udpsend 127.0.0.1 9000` — sends to Python bridge
- `dict.serialize @format json` — builds JSON string

### SysEx commands received from bridge:
| SysEx | Action |
|-------|--------|
| F0 7D 30 idx F7 | Jump to locator index |
| F0 7D 31 00 F7 | Next locator |
| F0 7D 32 00 F7 | Previous locator |

### Current status:
- v5 patch built and ready to paste into M4L
- `dict.serialize` approach may need testing — alternative is js scripting
- NOT YET TESTED end-to-end with UDP

---

## 8. INCOMPLETE / PLANNED FEATURES

### HIGH PRIORITY — In Progress:
- [ ] **M4L device testing** — v5 patch needs to be loaded, tested, verified UDP sends
- [ ] **iPad OSC receiver** — HTML needs to handle `type: "live_state"` JSON (currently only handles raw MIDI arrays)
- [ ] **Setlist page** — new page 10 in iPad HTML

### Setlist Page Design (APPROVED):
- Large swipeable cards — one song visible at a time
- Song name huge and centered (readable on dark stage)
- Swipe left/right to navigate songs
- Long press to drag/reorder
- One tap to activate (sends Program Change)
- **Song progress bar** (large): fills left to right, song title overlaid, time remaining shown right
- **Section progress bar** (small, above song bar): fills left to right, locator/section name overlaid
- Forward/Previous locator buttons
- Setlist reorder persists (saved to localStorage)
- Driven by locators pulled from Ableton automatically

### MEDIUM PRIORITY — Planned:
- [ ] Track Mute/Solo page
- [ ] Send FX page  
- [ ] XY Pad page
- [ ] Custom button labels (long-press to rename on KBD pages)
- [ ] Clip state feedback (8×8 grid visual states from Ableton)
- [ ] Track name display on Clip page headers (from Ableton)

### LOW PRIORITY — Future:
- [ ] Licensing/piracy protection (when ready to sell)
- [ ] Multiple setlist support
- [ ] Song notes/lyrics view

---

## 9. PYTHON BRIDGE — KEY DETAILS

**File:** `liverig_bridge_wired.py`  
**Virtual env:** `~/liverig-env/` (Python 3.14 via Homebrew)  
**Ports:** WebSocket 8765, UDP 9000  
**Virtual MIDI:** "LiveRig Bridge" (IN + OUT)

### Message types handled:
| type | Direction | Action |
|------|-----------|--------|
| `midi` | iPad→Mac | Forward raw MIDI bytes to Ableton |
| `live_state` | Mac→iPad | Broadcast Live state JSON to all clients |
| `setlist_reorder` | iPad→iPad | Broadcast reordered setlist to all clients |
| `locator_jump` | iPad→Mac | Send SysEx F0 7D 30 idx F7 |
| `locator_next` | iPad→Mac | Send SysEx F0 7D 31 00 F7 |
| `locator_prev` | iPad→Mac | Send SysEx F0 7D 32 00 F7 |
| `song_activate` | iPad→Mac | Send Program Change on CH1-4 |

### USB networking quirk:
- Requires **Personal Hotspot ON** on iPad to activate USB network interface
- USB link-local IP starts with 169.254.x.x
- mDNS hostname: `The-Beast-2147.local` (never changes)

---

## 10. LAUNCHER SCRIPT — KEY DETAILS

**File:** `LiveRig_Wired_Start.sh`  
**What it does:**
1. Detects USB IP address automatically
2. Injects IP into HTML via `sed` → `/tmp/liverig_controller_served.html`
3. Starts Python bridge (WebSocket + UDP)
4. Starts HTTP server on port 8080
5. Shows dialog with URL to open on iPad
6. Stops everything on "Stop LiveRig" click

---

## 11. KNOWN ISSUES / DECISIONS MADE

| Issue | Resolution |
|-------|-----------|
| Google Nest WiFi AP isolation | USB is only connection method |
| iPadOS USB networking | Personal Hotspot must be ON |
| `.maxpat` not recognized by Ableton | Use `.amxd` extension |
| MIDI feedback traffic concerns | Switched to UDP JSON (OSC-style) |
| `live.object` errors in M4L | Use `transport` object instead |
| `merge` object not in Max 8.6 | Use `pak` + separate outputs |

---

## 12. ENVIRONMENT

| Item | Detail |
|------|--------|
| Mac | The-Beast-2147, macOS 15 |
| Python | 3.14 via Homebrew, venv at ~/liverig-env/ |
| Ableton | Live Suite 12.3.7 with Max for Live |
| iPad | iPad Pro (USB-C), iPadOS latest |
| Browser | Safari (required for WebSocket + fullscreen) |
| Fonts | Share Tech Mono, Barlow Condensed (Google Fonts) |

---

## 13. HOW TO RECOVER THIS PROJECT

If starting fresh with a new Claude session, provide this document plus:
1. The contents of `live_rig_3_controller.html`
2. The contents of `liverig_bridge_wired.py`
3. Tell Claude: "Continue building LiveRig from this brief"

Claude will have full context to pick up exactly where we left off.

---

## 14. NEXT IMMEDIATE STEPS

1. Load LiveRig_Bridge v5 into M4L device in Ableton
2. Update iPad HTML to handle `type: "live_state"` JSON from bridge
3. Test full loop: Ableton plays → M4L → UDP → Bridge → WebSocket → iPad shows BPM
4. Build Setlist page (page 10) in iPad HTML
5. Rebuild DMG with updated HTML
6. Push everything to GitHub

