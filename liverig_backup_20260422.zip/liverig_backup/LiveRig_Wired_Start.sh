#!/usr/bin/env bash
# LiveRig Wired Start Script
# Place in ~/Desktop/liverig/ alongside liverig_bridge_wired.py and live_rig_3_controller.html

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BRIDGE="$SCRIPT_DIR/liverig_bridge_wired.py"
HTML_SRC="$SCRIPT_DIR/live_rig_3_controller.html"
HTML_OUT="/tmp/liverig_controller_served.html"
HTTP_PORT=8080
WS_PORT=8765
PID_FILE="/tmp/liverig_bridge.pid"
HTTP_PID_FILE="/tmp/liverig_http.pid"
LOG="/tmp/liverig_bridge.log"
HTTP_LOG="/tmp/liverig_http.log"

PYTHON="$HOME/liverig-env/bin/python3"
[ -f "$PYTHON" ] || PYTHON="$(which python3)"

notify() { osascript -e "display notification \"$1\" with title \"LiveRig\" sound name \"$2\"" 2>/dev/null || true; }

# Detect USB IP
BRIDGE_HOST=""
for iface in $(ifconfig -l 2>/dev/null); do
    ip=$(ipconfig getifaddr "$iface" 2>/dev/null || true)
    if [[ "$ip" == 169.254.* ]]; then
        BRIDGE_HOST="$ip"
        break
    fi
done
[ -z "$BRIDGE_HOST" ] && BRIDGE_HOST=$(ipconfig getifaddr en0 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}' || echo "NOT_DETECTED")

# Inject IP into HTML
sed "s|{{BRIDGE_HOST}}|$BRIDGE_HOST|g" "$HTML_SRC" > "$HTML_OUT"

# Start bridge
"$PYTHON" "$BRIDGE" > "$LOG" 2>&1 &
echo $! > "$PID_FILE"

# Start HTTP server
cd /tmp && "$PYTHON" -m http.server $HTTP_PORT > "$HTTP_LOG" 2>&1 &
echo $! > "$HTTP_PID_FILE"

sleep 1
notify "LiveRig started. Open Safari on iPad." "Glass"

URL="http://${BRIDGE_HOST}:${HTTP_PORT}/liverig_controller_served.html"

osascript << APPLEOF
display dialog "LiveRig is running.

Open on iPad:
$URL

Make sure:
  1. iPad plugged in via USB
  2. Personal Hotspot ON on iPad

Ableton setup (one time only):
  Preferences > MIDI > Input  'LiveRig Bridge' → Track ON, Remote ON
  Preferences > MIDI > Output 'LiveRig Bridge' → Track ON, Remote ON
  Drop LiveRig_Bridge.amxd on any MIDI track" buttons {"Stop LiveRig"} default button "Stop LiveRig" with title "LiveRig — Running"
APPLEOF

[ -f "$PID_FILE" ] && kill "$(cat "$PID_FILE")" 2>/dev/null && rm -f "$PID_FILE"
[ -f "$HTTP_PID_FILE" ] && kill "$(cat "$HTTP_PID_FILE")" 2>/dev/null && rm -f "$HTTP_PID_FILE"
notify "LiveRig stopped." "Funk"
